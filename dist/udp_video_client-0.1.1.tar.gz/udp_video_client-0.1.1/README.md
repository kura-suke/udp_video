# udp-video-client

```python
from client import VideoSender